package tw.edu.cse.nsysu;

import java.sql.*;
import java.io.File;
import java.util.List;     
import java.util.ArrayList;

public class Main{
    public static void main(String[] args){
        //Functionality buttons
        boolean importData=true;
        boolean featureExtract=true;
        boolean toSPMF=true;
        boolean runEclat=true;
        boolean runEclatFPgrowth=true;
        boolean runFPGrowth=true;
        boolean runModel=true;
        //Database connection string for SQLite database
        String db="jdbc:sqlite:db/SQLIA.db";
        Connection MyConn=null;
        //Declare the output file name and directory for SPMF input .txt file
        String OutputDir="data/processed";
        String OutputFile="SPMF_input_data.txt";
        String OutputName=OutputDir+"/"+OutputFile;
        try{
            //Construct connection to SQLIA.db
            MyConn=DriverManager.getConnection(db);
            System.out.println("--Database connection success!--");
            if (importData){
                //Start import csv data into database table
                DataImporter importer=new DataImporter(MyConn);
                importer.Import();
                System.out.println("--Data Import Success!--");
            }
            if(featureExtract){
                //Do feature extraction
                FeatureExtract MyExtract=new FeatureExtract();
                ExtractProcess processor=new ExtractProcess(MyExtract, MyConn);
                processor.FillFeatureVector();
                System.out.println("--Feature extraction complete!--");
            }
            if(toSPMF){
                //Make sure the output direstory exists
                File directory = new File(OutputDir);
                if (!directory.exists()) {
                    if (directory.mkdirs()) {
                        System.out.println("-- Created directory: " + OutputDir + " --");
                    }
                }
                 //Transfer to SPMF input .txt file 
                ToTransactionList transaction=new ToTransactionList(MyConn);
                transaction.Export(OutputName);
            }
            //Run association rule mining algorithms
            if(runEclat){
                //1. Eclat
                //Declare the minimum support threshold for Eclat algorithm
                double minSupport=0.1;
                String eclatDir="data/processed";
                String eclatOutput=eclatDir+"/Eclat_output_minSup_"+minSupport+".txt";
                String eclatInput="data/processed/SPMF_input_data.txt";
                Eclat eclat=new Eclat();
                eclat.EclatRunner(eclatInput, eclatOutput, minSupport);
            }
            if(runEclatFPgrowth){
                //2. FP-Growth
                //Declare the minimum support threshold for FP-Growth algorithm
                double minSupport=0.05; // Assuming this is the minimum support threshold (e.g., 10%)
                double minConf=0.8; // Assuming this is the minimum confidence threshold
                String fpgrowthDir="data/processed";
                String fpgrowthOutput=fpgrowthDir+"/Eclat_FPGrowth_output_minSup_"+minSupport+"_minConf_"+minConf+".txt";
                String fpgrowthInput="data/processed/SPMF_input_data.txt";
                Eclat_FPGrowth eclat_fpgrowth=new Eclat_FPGrowth();
                eclat_fpgrowth.runEclat_FPGrowth(fpgrowthInput, fpgrowthOutput, minSupport, minConf);
            }
            if(runFPGrowth){
                //3. FP-Growth
                //Declare the minimum support threshold for FP-Growth algorithm
                double minSupport=0.05; // Assuming this is the minimum support threshold (e.g., 10%)
                double minConf=0.8; // Assuming this is the minimum confidence threshold
                String fpgrowthDir="data/processed";
                String fpgrowthOutput=fpgrowthDir+"/FPGrowth_output_minSup_"+minSupport+"_minConf_"+minConf+".txt";
                String fpgrowthInput="data/processed/SPMF_input_data.txt";
                FPGrowth fpgrowth=new FPGrowth();
                fpgrowth.runFPGrowth(fpgrowthInput, fpgrowthOutput, minSupport, minConf);
            }
            if (runModel) {
                System.out.println("\n=== start model (CART & LightGBM) ===");
                TreeModel pipeline = new TreeModel();
                int situation = 1; 
                List<float[]> X = new ArrayList<>();
                List<Integer> Y = new ArrayList<>();
                String selectSql = "SELECT f1, f2, f3, f4, f5, f6, f7, f8, label FROM training_data";
                
                try (Statement stmt = MyConn.createStatement(); 
                     ResultSet r = stmt.executeQuery(selectSql)) {
                    
                    while (r.next()) {
                        float[] features = new float[8];
                        features[0] = r.getFloat("f1");
                        features[1] = r.getFloat("f2");
                        features[2] = r.getFloat("f3");
                        features[3] = r.getFloat("f4");
                        features[4] = r.getFloat("f5");
                        features[5] = r.getFloat("f6");
                        features[6] = r.getFloat("f7");
                        features[7] = r.getFloat("f8");
                        
                        int label = r.getInt("label");
                        
                        X.add(features);
                        Y.add(label);
                    }
                }
                pipeline.runPipeline(X, Y, "Scenario " + situation);
            }
              
        }catch(SQLException e){
            System.err.println("Connection to database fail: "+e.getMessage());
            e.printStackTrace();
        }catch(Exception e){
            System.err.println("Unexpected error happens: "+e.getMessage());
            e.printStackTrace();
        }finally{
            try{
                //Close the database connection
                if(MyConn!=null){
                    MyConn.close();
                    System.out.println("--Connection to database closed!--");
                }
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
}